export const environment = {
    HOST: "http://localhost:9090",
    RETRY:2,
    TOKEN_NAME: 'access_token'
};
