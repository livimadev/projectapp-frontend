export class Course{
    idCourse: number;
    code: string;
    name: string;
}