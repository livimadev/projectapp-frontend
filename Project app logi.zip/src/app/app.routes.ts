import { Routes } from '@angular/router';
import { CourseComponent } from './pages/course/course.component';
import { TeacherComponent } from './pages/teacher/teacher.component';
import { CourseEditComponent } from './pages/course/course-edit/course-edit.component';
import { LoginComponent } from './pages/login/login.component';

export const routes: Routes = [
    { path:'', redirectTo:'login', pathMatch:'full'},
    {path:'login', component:LoginComponent},
    {
        path: 'pages/course',
        component: CourseComponent, children: [
            { path: 'new', component: CourseEditComponent },
            { path: 'edit/:id', component: CourseEditComponent },
        ],
    },
    { path: 'pages/teacher', component: TeacherComponent },
];
